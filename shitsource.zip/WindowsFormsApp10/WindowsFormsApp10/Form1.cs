﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Indieteur.GlobalHooks;
using Memory;

namespace WindowsFormsApp10
{
    public partial class Form1 : Form
    {
        Minecraft Minecraft = new Minecraft();
        public Mem MemLib = new Mem();
        int r = 255, gr = 0, b = 0;
        Pen myPen = new Pen(Color.Red, 3);
        private Point MovePanel;
        Random random = new Random();
        int spinSpeed;
        public static SolidBrush white = new SolidBrush(Color.FromArgb(120, 120, 126));
       

        bool rainbowGui = false;

        string Zoom = "C";
        string Speed = "";
        string AntiAim = "";
        string ClickGui = "";
        string NoWater = "";
        string FastBreak = "";
        string NoWeb = "";
        string Sprint = "";
        string NoSwing = "";
        string FullBright = "";


        [DllImport("user32.dll")]
        static extern short GetAsyncKeyState(Keys vKey);

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            
            int mcProc = MemLib.GetProcIdFromName("Minecraft.Windows");
            if (mcProc < 1 )
            {
                MessageBox.Show("Minecraft is not running");
                Environment.Exit(0);
            }
            this.TopMost = true;
            Minecraft.Inject();
        }
        private void consoleKeys()
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (GetAsyncKeyState(Keys.W) < 0)
            {
                guna2Button16.CustomBorderColor = Color.FromArgb(213, 0, 0);
            }
            else
            {
                guna2Button16.CustomBorderColor = Color.FromArgb(103, 58, 183);
            }
            if (GetAsyncKeyState(Keys.S) < 0)
            {
                guna2Button14.CustomBorderColor = Color.FromArgb(213, 0, 0);
            }
            else
            {
                guna2Button14.CustomBorderColor = Color.FromArgb(103, 58, 183);
            }
            if (GetAsyncKeyState(Keys.A) < 0)
            {
                guna2Button13.CustomBorderColor = Color.FromArgb(213, 0, 0);
            }
            else
            {
                guna2Button13.CustomBorderColor = Color.FromArgb(103, 58, 183);
            }
            if (GetAsyncKeyState(Keys.D) < 0)
            {
                guna2Button15.CustomBorderColor = Color.FromArgb(213, 0, 0);
            }
            else
            {
                guna2Button15.CustomBorderColor = Color.FromArgb(103, 58, 183);
            }
            if (GetAsyncKeyState(Keys.Space) < 0)
            {
                guna2Button17.CustomBorderColor = Color.FromArgb(213, 0, 0);
            }
            else
            {
                guna2Button17.CustomBorderColor = Color.FromArgb(103, 58, 183);
            }
            if (guna2Button28.Checked == true)
            {
                Minecraft.noSwing();
            }
            else
            {
                Minecraft.enableSwing();
            }
            if (guna2Button9.Checked == true)
            {
                if (GetAsyncKeyState(Keys.W) < 0)
                {
                    Minecraft.autoSprint();
                }
                else
                {
                    Minecraft.normalWalk();
                }
            }
            if (guna2Button3.Checked == true)
            {
                Minecraft.ultraRapid();
            }
            if (guna2Button5.Checked == true)
            {
                Minecraft.rapidHit();
            }
            if (guna2Button6.Checked == true)
            {
                Minecraft.speedHack();
            }
            if (guna2Button10.Checked == true)
            {
                Minecraft.fastFall();
            }
            if (guna2Button8.Checked == true)
            {
                Minecraft.spider();
            }
            if (guna2Button2.Checked == true)
            {
                Minecraft.instabreak = 1;
                Minecraft.instaBreak();
            }
            else
            {
                Minecraft.instabreak = 0;
            }

            if (guna2Button1.Checked == true)
            {
                if (GetAsyncKeyState(Keys.C) < 0)
                {
                    Minecraft.hideHand();
                    Minecraft.Zoom();
                }
                else
                {
                    Minecraft.showHand();
                    Minecraft.unZoom();
                }
            }
            if (guna2Button7.Checked == true)
            {
                Minecraft.brightness();
            }
            else
            {
                Minecraft.normalBright();
            }
            if (guna2Button4.Checked == true)
            {
                Minecraft.clearWater();
            }
            else
            {
                Minecraft.normalWater();
            }
            if (Control.IsKeyLocked(Keys.Insert))
            {
                guna2Panel2.Visible = true;
                guna2Panel3.Visible = true;
                guna2Panel4.Visible = true;
                guna2Panel5.Visible = true;
            }
            else
            {
                guna2Panel2.Visible = false;
                guna2Panel3.Visible = false;
                guna2Panel4.Visible = false;
                guna2Panel5.Visible = false;
            }
        }
        private void consoleCommands()
        {
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer3_Tick_1(object sender, EventArgs e)
        {
        }

        private void guna2TextBox2_KeyDown(object sender, KeyEventArgs e)
        {
        }

        private void timer3_Tick_2(object sender, EventArgs e)
        {
        }

        private void guna2Panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {
        }

        private void guna2TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Panel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void guna2Panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
                MovePanel = e.Location;
            }
        }

        private void guna2Panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {

            }
        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button3_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel2_Paint_2(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                MovePanel = e.Location;
            }
        }

        private void guna2Panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                guna2Panel2.Left = e.X + guna2Panel2.Left - MovePanel.X;
                guna2Panel2.Top = e.Y + guna2Panel2.Top - MovePanel.Y;
            }
        }

        private void guna2Panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
        }

        private void Zoom_Tick(object sender, EventArgs e)
        {

        }

        private void guna2Panel3_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                guna2Panel3.Left = e.X + guna2Panel3.Left - MovePanel.X;
                guna2Panel3.Top = e.Y + guna2Panel3.Top - MovePanel.Y;
            }
        }

        private void guna2Panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                MovePanel = e.Location;
            }
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {

        }

        private void guna2Panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button6_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button6_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {

        }

        private void guna2HtmlToolTip2_Popup(object sender, PopupEventArgs e)
        {

        }

        private void guna2Button1_MouseLeave(object sender, EventArgs e)
        {

        }

        private void guna2Button1_MouseHover(object sender, EventArgs e)
        {
            guna2HtmlToolTip1.SetToolTip(guna2Button1, "Allows your player to zoom");
        }

        private void guna2Button6_MouseHover(object sender, EventArgs e)
        {
        }

        private void guna2Button7_MouseHover(object sender, EventArgs e)
        {
        }

        private void guna2HtmlToolTip3_Popup(object sender, PopupEventArgs e)
        {

        }

        private void guna2Panel4_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                MovePanel = e.Location;
            }
        }

        private void guna2Panel4_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                guna2Panel4.Left = e.X + guna2Panel4.Left - MovePanel.X;
                guna2Panel4.Top = e.Y + guna2Panel4.Top - MovePanel.Y;
            }
        }

        private void guna2Panel5_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                MovePanel = e.Location;
            }
        }

        private void guna2Panel5_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                guna2Panel5.Left = e.X + guna2Panel5.Left - MovePanel.X;
                guna2Panel5.Top = e.Y + guna2Panel5.Top - MovePanel.Y;
            }
        }

        private void guna2Button6_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Button7_Click_1(object sender, EventArgs e)
        {
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button8_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Button2_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Button6_Click_2(object sender, EventArgs e)
        {

        }

        private void guna2TrackBar2_Scroll(object sender, ScrollEventArgs e)
        {
            
        }

        private void guna2TrackBar1_Scroll(object sender, ScrollEventArgs e)
        {
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void guna2TrackBar4_Scroll(object sender, ScrollEventArgs e)
        {
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void guna2HtmlToolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void guna2TrackBar1_MouseHover(object sender, EventArgs e)
        {
        }

        private void label3_Click_2(object sender, EventArgs e)
        {

        }

        private void label3_MouseHover(object sender, EventArgs e)
        {
        }

        private void label13_MouseHover(object sender, EventArgs e)
        {
        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Button10_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox2_TextChanged_1(object sender, EventArgs e)
        {
        }
        private void guna2Button16_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button12_Click(object sender, EventArgs e)
        {
        }

        private void timer3_Tick_3(object sender, EventArgs e)
        {
            Minecraft.spinbot += 5;
        }

        private void guna2ResizeBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button11_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox2_KeyDown_1(object sender, KeyEventArgs e)
        {

        }

        private void guna2Button20_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button19_Click(object sender, EventArgs e)
        {

        }

        private void timer3_Tick_4(object sender, EventArgs e)
        {
            if (guna2Button26.Checked == true)
            {
                Minecraft.spinBot();
                Minecraft.spinbot += spinSpeed;
            }
            else
            {
                Minecraft.spinDisable();
            }
        }

        private void guna2TextBox3_TextChanged_1(object sender, EventArgs e)
        {
        }

        private void guna2Panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button18_Click(object sender, EventArgs e)
        {
            if(guna2Button18.Checked == true)
            {
                guna2Button16.Visible = false;
                guna2Button14.Visible = false;
                guna2Button13.Visible = false;
                guna2Button17.Visible = false;
                guna2Button15.Visible = false;
            }
            else
            {
                guna2Button16.Visible = true;
                guna2Button14.Visible = true;
                guna2Button13.Visible = true;
                guna2Button17.Visible = true;
                guna2Button15.Visible = true;
            }
        }

        private void guna2Button24_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button26_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox4_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
            }
            catch
            {
            }
        }

        private void guna2Button27_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button28_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button27_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button4_MouseHover(object sender, EventArgs e)
        {
            guna2HtmlToolTip2.SetToolTip(guna2Button4, "Allows your player to walk in water");
        }

        private void guna2Button7_MouseLeave(object sender, EventArgs e)
        {
        }

        private void guna2Button4_MouseLeave(object sender, EventArgs e)
        {
        }

        private void guna2Button7_MouseHover_1(object sender, EventArgs e)
        {
            guna2HtmlToolTip3.SetToolTip(guna2Button7, "Changes how lighting works");
        }

        private void guna2Button26_MouseLeave(object sender, EventArgs e)
        {
        }

        private void guna2Button26_MouseHover(object sender, EventArgs e)
        {
            guna2HtmlToolTip6.SetToolTip(guna2Button26, "Makes your head move around");
        }

        private void guna2Button2_MouseHover(object sender, EventArgs e)
        {
            guna2HtmlToolTip4.SetToolTip(guna2Button2, "Reduce the delay between breaking blocks");
        }

        private void guna2Button9_MouseLeave(object sender, EventArgs e)
        {
        }

        private void guna2Button9_MouseHover(object sender, EventArgs e)
        {
            guna2HtmlToolTip9.SetToolTip(guna2Button9, "Improves Sprinting");
        }

        private void guna2Button10_MouseHover(object sender, EventArgs e)
        {
        }

        private void guna2Button20_MouseLeave(object sender, EventArgs e)
        {
        }

        private void guna2Button28_MouseHover(object sender, EventArgs e)
        {
            guna2HtmlToolTip7.SetToolTip(guna2Button28, "Disables your hand from swinging (Client - Sided)");

        }

        private void guna2Button28_MouseLeave(object sender, EventArgs e)
        {
        }

        private void guna2Button2_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void guna2Button2_MouseLeave(object sender, EventArgs e)
        {
        }

        private void guna2Button6_MouseHover_1(object sender, EventArgs e)
        {
            guna2HtmlToolTip8.SetToolTip(guna2Button6, "Makes your player move faster | Speed: " + Minecraft.speed);
        }

        private void guna2Button6_MouseLeave(object sender, EventArgs e)
        {
        }

        private void guna2Button10_MouseLeave(object sender, EventArgs e)
        {
        }

        private void guna2Button6_MouseDown_1(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
            }
        }

        private void guna2Button3_Click_1(object sender, EventArgs e)
        {
            
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Panel6_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void guna2Button3_Click_2(object sender, EventArgs e)
        {

        }

        private void guna2Button26_MouseDown(object sender, MouseEventArgs e)
        {
        }

        private void guna2TextBox3_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void guna2TextBox2_TextChanged_2(object sender, EventArgs e)
        {
            
        }

        private void guna2TextBox2_KeyDown_2(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                try
                {
                    if (guna2TextBox2.Text == "inject")
                    {
                        Minecraft.Inject();
                    }
                    if (guna2TextBox2.Text == "close")
                    {
                        Application.Exit();
                    }
                    if (guna2TextBox2.Text == $"{"antiaim"} {"speed"} {guna2TextBox2.Text.Split(' ')[2]}")
                    {
                        spinSpeed = Convert.ToInt32(guna2TextBox2.Text.Split(' ')[2]);
                    }
                    if (guna2TextBox2.Text == $"{"speed"} {"value"} {guna2TextBox2.Text.Split(' ')[2]}")
                    {
                        Minecraft.speed = (float)Convert.ToDouble(guna2TextBox2.Text.Split(' ')[2]);
                    }
                    if (guna2TextBox2.Text == $"{"rainbow"} {"gui"} {"true"}")
                    {
                        timer4.Enabled = true;
                    }
                    if (guna2TextBox2.Text == $"{"rainbow"} {"gui"} {"false"}")
                    {
                        timer4.Enabled = false;
                    }
                    if (guna2TextBox2.Text == $"{"change"} {"name"} {guna2TextBox2.Text.Split(' ')[2]}")
                    {
                        Minecraft.userInput = guna2TextBox2.Text.Split(' ')[2];
                        Minecraft.userName();
                    }
                    if (guna2TextBox2.Text == $"{"volume"} {"music"} {guna2TextBox2.Text.Split(' ')[2]}")
                    {
                        Minecraft.musicVolume = (float)Convert.ToDouble(guna2TextBox2.Text.Split(' ')[2]);
                        Minecraft.highMusic();
                    }
                    if (guna2TextBox2.Text == $"{"fastfall"} {"speed"} {guna2TextBox2.Text.Split(' ')[2]}")
                    {
                        Minecraft.fallingSpeed = (float)Convert.ToDouble(guna2TextBox2.Text.Split(' ')[2]);
                    }
                }
                catch
                {

                }

            }
        }

        private void guna2Button6_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void label2_Click_2(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Button3_Click_3(object sender, EventArgs e)
        {

        }

        private void guna2Panel6_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void guna2Panel6_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void guna2Button1_MouseMove(object sender, MouseEventArgs e)
        {

        }

        private void guna2HtmlToolTip5_Popup(object sender, PopupEventArgs e)
        {

        }

        private void timer4_Tick(object sender, EventArgs e)
        {
                guna2Panel2.CustomBorderColor = Color.FromArgb(r, gr, b);
                guna2Panel3.CustomBorderColor = Color.FromArgb(r, gr, b);
                guna2Panel4.CustomBorderColor = Color.FromArgb(r, gr, b);
                guna2Panel5.CustomBorderColor = Color.FromArgb(r, gr, b);
                if (r > 0 && b == 0)
                {
                    r--;
                    gr++;
                }
                if (gr > 0 && r == 0)
                {
                    gr--;
                    b++;
                }
                if (b > 0 && gr == 0)
                {
                    b--;
                    r++;
            }
        }

        private void guna2Button3_Click_4(object sender, EventArgs e)
        {

        }

        private void guna2Button5_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void guna2Button8_Click_2(object sender, EventArgs e)
        {

        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void guna2Button8_MouseHover(object sender, EventArgs e)
        {
            guna2HtmlToolTip10.SetToolTip(guna2Button8, "Allows you to climb up walls like a spider");
        }

        private void guna2Button10_MouseHover_1(object sender, EventArgs e)
        {
            guna2HtmlToolTip12.SetToolTip(guna2Button10, "Increases fall speed");

        }

        private void guna2HtmlToolTip11_Popup(object sender, PopupEventArgs e)
        {

        }

        private void guna2Button5_MouseHover(object sender, EventArgs e)
        {
            guna2HtmlToolTip11.SetToolTip(guna2Button5, "Reduce the delay between hitting things");
        }

        private void guna2Button10_Click_1(object sender, EventArgs e)
        {

        }

        private void guna2Button3_MouseEnter(object sender, EventArgs e)
        {

        }

        private void guna2Button3_MouseHover(object sender, EventArgs e)
        {
            guna2HtmlToolTip14.SetToolTip(guna2Button3, "Removes the delay for placing blocks and hitting things");
        }

        private void guna2Button3_Click_5(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label6.Text = "" + DateTime.Now.ToLongTimeString();
            label5.Text = "Pitch: " + Minecraft.getPitch();
            label4.Text = "Yaw: " + Minecraft.getYaw();
            label2.Text = "X: " + Minecraft.getPosition("X") + ", Y: " + Minecraft.getPosition("Y") + ", Z: " + Minecraft.getPosition("Z");
       
        }
    }
}
