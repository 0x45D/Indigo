﻿using Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    class Minecraft
    {
        public Mem MemLib = new Mem();
        public int zoomValue = 30;
        public int unZoomValue = 110;
        public int boostAmount = 100;
        public int onoff = 1;
        public int instabreak = 1;
        public int hideShow = 1;
        public float speed = 0.4f;
        public float sprint = 0.1299999952f;
        public float normal = 0.1000000015f;
        public float spinbot;
        public string userInput;
        public float musicVolume = 1f;
        public float velocity;
        public float fallingSpeed = -1;
        public float dogClass;


        public void Inject()
        {
            MemLib.OpenProcess("Minecraft.Windows");
        }
        //niggerflesh
        public float getPosition(string XYorZ)
        {
            if (XYorZ == "X")
            {
                {
                    return MemLib.ReadFloat("Minecraft.Windows.exe+0x03586B38,0x168,0x260,0x390,0x48,0x140,0x180,0x0,0x480");
                }
            }
            else if (XYorZ == "Y")
            {
                {
                    return MemLib.ReadFloat("Minecraft.Windows.exe+0x03586B38,0x168,0x260,0x390,0x48,0x140,0x180,0x0,0x484");
                }
            }
            else if (XYorZ == "Z")
            {
                {
                    return MemLib.ReadFloat("Minecraft.Windows.exe+0x03586B38,0x168,0x260,0x390,0x48,0x140,0x180,0x0,0x488");
                }
            }
            return 0.00f;
        }
        public float getPitch()
        {
            return MemLib.ReadFloat("Minecraft.Windows.exe+0x03586B38,0x168,0x260,0x390,0x48,0x140,0x180,0x0,0x128");
        }

        public float getYaw()
        {

            return MemLib.ReadFloat("Minecraft.Windows.exe+0x03586B38,0x168,0x260,0x390,0x48,0x140,0x180,0x0,0x12C");
        }
        public float getVelocity(string XYorZ)
        {
            if (XYorZ == "X")
            {
                return MemLib.ReadFloat("Minecraft.Windows.exe+0x03586B38,0x168,0x260,0x390,0x48,0x140,0x180,0x0,0x4BC");
            }
            else if (XYorZ == "Y")
            {
                return MemLib.ReadFloat("Minecraft.Windows.exe+0x03586B38,0x168,0x260,0x390,0x48,0x140,0x180,0x0,0x4C0");
            }
            else if (XYorZ == "Z")
            {
                return MemLib.ReadFloat("Minecraft.Windows.exe+0x03586B38,0x168,0x260,0x390,0x48,0x140,0x180,0x0,0x4C4");
            }
            return 0.00f;
        }
        public void Zoom()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x03586B38,0xAD0,0x20,0x1A0,0xC8,0x0,0x120,0x1E8", "float", $"{zoomValue}");
        }
        public void unZoom()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x03586B38,0xAD0,0x20,0x1A0,0xC8,0x0,0x120,0x1E8", "float", $"{unZoomValue}");
        }
        public void alwaysDay()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+03666958,0x10,0x0,0x0,0x18,0xB0,0x358,0x5C0", "float", $"-1");
        }
        public float getFov()
        {
            return MemLib.ReadFloat("Minecraft.Windows.exe+0x03586B38,0xAD0,0x20,0x1A0,0xC8,0x0,0x120,0x1E8");
        }
        public float getText()
        {
            return MemLib.ReadInt("Minecraft.Windows.exe+0x0366AFF0,0x8,0x8,0x50,0x7E8,0x38,0x38");
        }
        public float getTime()
        {
            return MemLib.ReadFloat("Minecraft.Windows.exe+0x03666958,0x10,0x0,0x0,0x18,0xB0,0x358,0x5C0");
        }
        public void showCoords()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x50,0x1F8,0x18,0x20,0x30,0x308,0x9A4", "byte", $"{onoff}");
        }
        public void instaBreak()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0xBD0,0xB0,0x98,0x38,0x8,0x20", "float", $"{instabreak}");
        }
        public void userName()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0x868", "string", $"{userInput}");
        }
        public void clearWater()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x193653C", "bytes", "0x90 0x90 0x90 0x90 0x90 0x90 0x90");
        }
        public void normalWater()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x193653C", "bytes", "C6 87 45 02 00 00 01");
        }
        public void brightness()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035DF8E8,0x20,0xBF8,0xE0,0x8,0x128,0x138,0x1E8", "float", "100");
        }
        public void normalBright()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035DF8E8,0x20,0xBF8,0xE0,0x8,0x128,0x138,0x1E8", "float", "1");
        }
        public void speedHack()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0x460,0x40,0xC8,0x18,0x1F8,0x9C", "float", $"{speed}");
        }
        public void autoSprint()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0x460,0x40,0xC8,0x18,0x1F8,0x9C", "float", $"{sprint}");
        }
        public void normalWalk()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0x460,0x40,0xC8,0x18,0x1F8,0x9C", "float", $"{normal}");
        }
        public float speedMeter()
        {
            return MemLib.ReadFloat("Minecraft.Windows.exe+0x035F9470,0x70,0x460,0x40,0xC8,0x18,0x1F8,0x9C");
        }
        public void hideHand()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035DF8E8,0x20,0xC38,0x1D8,0x8,0x0,0xCD0,0x1E0", "byte", "1");
        }
        public void showHand()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035DF8E8,0x20,0xC38,0x1D8,0x8,0x0,0xCD0,0x1E0", "byte", "0");
        }
        public void spinBot()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x50,0x7F8,0x0,0x18,0x8,0xD0,0x670", "float", $"{spinbot}");
            MemLib.WriteMemory("Minecraft.Windows.exe+0x1D4A157", "bytes", "0x90 0x90 0x90 0x90 0x90 0x90 0x90 0x90");
        }
        public void highMusic()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x03600610,0x110,0x68,0x18,0xC8,0x30,0xE8,0x488", "float", $"{musicVolume}");
        }
        public void spinDisable()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x1D4A157", "bytes", "F3 0F 11 87 70 06 00 00");
        }
        public void VelocityX()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0x4BC", "float", $"");
        }
        public void VelocityY()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0x4C0", "float", $"{velocity}");
        }
        public void VelocityZ()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0x4C4", "float", $"");
        }
        public void fallingSpeedY()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0x4C0", "float", $"{fallingSpeed}");
        }
        public void dogClassen()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035F9470,0x70,0x4C0", "float", $"{dogClass}");
        }
        public void spider()
        {
            if(onGround() == 16843009 | onGround() == 65536)
            {
                velocity = 0.75f;
                VelocityY();
            }
        }
        public int onGround()
        {
            return MemLib.ReadInt("Minecraft.Windows.exe+0x035F9470,0x70,0x1C0");
        }
        public void noSwing()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x175DDD1", "bytes", "0x90 0x90 0x90 0x90 0x90 0x90 0x90 0x90");
        }
        public void enableSwing()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x175DDD1", "bytes", "F3 0F 11 8B E0 06 00 00");
        }
        public void antiAim()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x1D4A157", "bytes", "0x90 0x90 0x90 0x90 0x90 0x90 0x90 0x90");

        }
        public void disableAntiAim()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x1D4A0DA", "bytes", "F3 0F 11 87 70 06 00 00");
        }
        public void rapidHit()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035CDEB0,0x18,0x0,0x100,0x48,0x2E0,0x88,0x50", "byte", "0");
        }
        public int fallDistance()
        {
            return MemLib.ReadInt("Minecraft.Windows.exe+0x035F9470,0x70,0x1BC");
        }
        public void fastFall()
        {
            if (onGround() == 0)
            {
                fallingSpeed = -1f;
                fallingSpeedY();
            }
        }
        public void ultraRapid()
        {
            MemLib.WriteMemory("Minecraft.Windows.exe+0x035CDEB0,0x18,0x0,0x100,0x48,0x2E0,0x88,0x50", "int", "0");
            MemLib.WriteMemory("Minecraft.Windows.exe+0x11E49CF", "bytes", "0x90 0x90 0x90");
        }
    }
}

